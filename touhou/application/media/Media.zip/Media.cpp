
#include"Media.h"
 // ���� _bstr_t ���� COM �������
MediaPlay::MediaPlay() {
	
}
std::atomic<bool> shouldStop(false);
int MediaPlay::stop() {
	std::cout << "stop" << std::endl;
	shouldStop.store(true);
	
	
	return 0;
}
int MediaPlay::releaseAll() {
	// ������Щ�ӿ��Ѿ�����ȷ��ʼ����ʹ��

// ���ȣ��ͷ�IBasicAudio�ӿ�
	std::cout << "׼���ͷ�" << std::endl;
	if (basicAudio != NULL) {
		basicAudio->Release();
		basicAudio = NULL; // ��ָ������ΪNULL���Ա�������ָ��
	}

	// ���ţ��ͷ�IMediaSeeking�ӿ�
	if (mediaSeek != NULL) {
		mediaSeek->Release();
		mediaSeek = NULL;
	}

	// Ȼ���ͷ�IMediaEvent�ӿ�
	if (mediaEvent != NULL) {
		mediaEvent->Release();
		mediaEvent = NULL;
	}

	// ���ţ��ͷ�IMediaControl�ӿ�
	if (mediaControl != NULL) {
		mediaControl->Release();
		mediaControl = NULL;
	}

	// ����ͷ�IGraphBuilder�ӿ�
	if (graphBullder != NULL) {
		graphBullder->Release();
		graphBullder = NULL;
	}
	std::cout << "�ͷ����" << std::endl;
	return 0;
}
int MediaPlay::begin() {
	return 0;
}
int MediaPlay::play(const std::string path_s_) {
    std::string path = path_s_;
    media(path.c_str());
	
	return 0;
}
MediaPlay::~MediaPlay() {
	releaseAll();
}

int MediaPlay::media(const char* filePath) {
    HRESULT result = CoInitialize(NULL);
    if (FAILED(result)) {
        std::cerr << "Failed to initialize COM library: " << _com_error(result).ErrorMessage() << std::endl;
        return 1;
    }

    result = CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER, IID_IFilterGraph, (void**)&graphBullder);
    if (FAILED(result)) {
        std::cerr << "Failed to create Filter Graph: " << _com_error(result).ErrorMessage() << std::endl;
        CoUninitialize();
        return 2;
    }

    result = graphBullder->QueryInterface(IID_IMediaControl, (void**)&mediaControl);
    if (FAILED(result)) {
        std::cerr << "Failed to get IMediaControl interface: " << _com_error(result).ErrorMessage() << std::endl;
        releaseAll();
        return 3;
    }

    result = graphBullder->QueryInterface(IID_IMediaEvent, (void**)&mediaEvent);
    if (FAILED(result)) {
        std::cerr << "Failed to get IMediaEvent interface: " << _com_error(result).ErrorMessage() << std::endl;
        releaseAll();
        return 4;
    }

    result = mediaControl->QueryInterface(IID_IMediaSeeking, (void**)&mediaSeek);
    if (FAILED(result)) {
        std::cerr << "Failed to get IMediaSeeking interface: " << _com_error(result).ErrorMessage() << std::endl;
        releaseAll();
        return 5;
    }

    int len = MultiByteToWideChar(CP_ACP, 0, filePath, -1, NULL, 0);
    wchar_t* path = new wchar_t[len];
    MultiByteToWideChar(CP_ACP, 0, filePath, -1, path, len);

    result = graphBullder->RenderFile(path, NULL);
    delete[] path; // �ͷ�·���ڴ�
    if (FAILED(result)) {
        std::cerr << "Failed to render file: " << _bstr_t(filePath) << std::endl;
        releaseAll();
        return 6;
    }

    result = graphBullder->QueryInterface(IID_IBasicAudio, (void**)&basicAudio);
    if (FAILED(result)) {
        std::cerr << "Failed to get IBasicAudio interface: " << _com_error(result).ErrorMessage() << std::endl;
        releaseAll();
        return 7;
    }
    
    basicAudio->put_Balance(0);
    basicAudio->put_Volume(-500);

    LONGLONG longTemp = 0;
    result = mediaSeek->GetDuration(&longTemp);
    if (FAILED(result)) {
        std::cerr << "Failed to get media duration: " << _com_error(result).ErrorMessage() << std::endl;
        return -1;
    }
    else {
        double durationInSeconds = double(longTemp) / 10000000.0;
        std::cout << "Duration: " << longTemp << "ns (" << durationInSeconds << "s)" << std::endl;
    }

    result = mediaControl->Run();
    if (FAILED(result)) {
        std::cerr << "Failed to run media: " << _com_error(result).ErrorMessage() << std::endl;
        releaseAll();
        return 8;
    }

    long log = 0;
    while (true) {
        if (shouldStop.load()) {
            mediaControl->Stop();
            break;
        }
        result = mediaEvent->WaitForCompletion(500, &log); // ʹ�ý϶̵ĳ�ʱʱ�������ڼ��ֹͣ��־
        if (SUCCEEDED(result) || shouldStop.load()) {
            break;
        }
    }

    if (FAILED(result) && !shouldStop.load()) {
        std::cerr << "Failed to wait for media completion: " << _com_error(result).ErrorMessage() << std::endl;
        releaseAll();
        return 9;
    }
    return 0;
}