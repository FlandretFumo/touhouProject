#pragma once
#include<Windows.h>
#include<iostream>
#include<dshow.h>
#include<thread>
#include<string>
#include <chrono>
#include <comdef.h>
class MediaPlay {
public:
	MediaPlay();
	~MediaPlay();
	int releaseAll();
	int play(const std::string path_s);
	int stop();
	int begin();
private:
	int media(const char* filePath);
	IGraphBuilder* graphBullder = NULL;
	IMediaControl* mediaControl = NULL;
	IMediaEvent* mediaEvent = NULL;
	IMediaSeeking* mediaSeek = NULL;
	IBasicAudio* basicAudio = NULL;
};